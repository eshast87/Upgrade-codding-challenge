package com.upgrade.constants;



public class LoginPageConstant {
	

	public static final String firstName_Byname = "borrowerFirstName";
	public static final String lastName_Byname = "borrowerLastName";
	public static final String browserStreet_ByclassName = "geosuggest__input";
	public static final String borrowerCity_Byname = "borrowerCity";
	public static final String borrowerState_Byname = "borrowerState";
	public static final String borrowerZipCode_Byname = "borrowerZipCode";
	public static final String borrowerDateOfBirth_Byname = "borrowerDateOfBirth";
	public static final String borrowerIncome_Byname = "borrowerIncome";
	public static final String borrowerAdditionalIncome_Byname = "borrowerAdditionalIncome";
	public static final String username_Byname = "username";
	public static final String password_Byname = "password";
	public static final String check_boxterms_Byxpath = "//div[@class='sc-kPVwWT sc-kfGgVZ ghCrQD']";
	public static final String check_ratebutton_Byxpath = "//button[@class='section sc-brqgnP iKoMvw']";

}

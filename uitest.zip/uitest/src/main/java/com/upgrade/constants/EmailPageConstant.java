package com.upgrade.constants;


public class EmailPageConstant {
	

	public static final String inputBox_Byxpath = "//input[@name='username']";
	public static final String passwordbox_Byxpath = "//input[@name='password']";
	public static final String signIn_textbutton_Byxpath = " //button[@class='sc-jTzLTM ibAgVm']";

}

package com.upgrade.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.upgrade.constants.HomePageConstant;

public class RefactoredHomePage {
	ExtentTest test;
	public WebDriver driver; 
	
      public RefactoredHomePage(WebDriver driver , ExtentTest test) {
			// TODO Auto-generated constructor stub
			this.driver = driver;
			this.test= test;
		}
      
      	By laonAmount = By.name(HomePageConstant.laonAmount_byName);
		By purpose = By.xpath(HomePageConstant.purpose_Byxpath);
		By checkyourRate = By.xpath(HomePageConstant.checkyourRate_Byxpath);
		
		public void  fill_in_loanAmmount() {
			WebElement fill_in_loanAmmount = driver.findElement(laonAmount);
			
			fill_in_loanAmmount.sendKeys("2000");
			test.log(LogStatus.INFO, "Clicked on Loan Amount");
			//test.pass("details", MediaEntityBuilder.createScreenCaptureFromPath("screenshot.png").build());
			
		}
		
		public void  fill_in_purpose() {
			Select fill_in_purpose = new Select(driver.findElement(purpose));
			
			fill_in_purpose.selectByVisibleText("Business");
			test.log(LogStatus.INFO, "Purpose as  Business selected ");
		}
		
		public void click_checkyourRate() {
			WebElement click_checkyourRate = driver.findElement(checkyourRate);
			
			click_checkyourRate.click();
			test.log(LogStatus.INFO, "CheckYourRate is clicked");
			test.log(LogStatus.PASS, "Upgrade First Page Successfully Automated");
		}
	



}

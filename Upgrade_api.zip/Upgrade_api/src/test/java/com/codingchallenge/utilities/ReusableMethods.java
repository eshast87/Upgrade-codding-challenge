package com.codingchallenge.utilities;

import org.json.JSONArray;
import org.json.JSONObject;

import com.github.scribejava.core.model.Response;

import io.restassured.path.json.JsonPath;
import io.restassured.path.xml.XmlPath;

public class ReusableMethods {


	public static XmlPath rawToXML(Response r)
	{
		String respon=r.toString();
		XmlPath x=new XmlPath(respon);
		return x;

	}

	public static JsonPath rawToJson(Response r)
	{ 
		String respon=r.toString();
		JsonPath x=new JsonPath(respon);
		return x;
	}

	public static JSONObject stringToJsonObject(Response r) {
		String respon=r.toString();
		JSONObject js_object = new JSONObject(respon);
		return js_object;
	}


	//JSONArray obj_JSONArray = js_object.getJSONArray("states");
	public static JSONArray jsonObjectToJsonArray(JSONObject js_object,String ojectString) {
		JSONArray obj_JSONArray = js_object.getJSONArray(ojectString);
		return obj_JSONArray;
	}
	
}


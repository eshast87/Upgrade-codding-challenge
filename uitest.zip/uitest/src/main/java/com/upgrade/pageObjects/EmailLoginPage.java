package com.upgrade.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.upgrade.constants.EmailPageConstant;


public class EmailLoginPage {
	ExtentReports reports;
	    ExtentTest test;
	
		
		
		public EmailLoginPage(WebDriver driver,ExtentTest test) {
			// TODO Auto-generated constructor stub
			this.driver = driver;
			this.test=test;
		}

		public WebDriver driver; 

		By inputBox = By.xpath(EmailPageConstant.inputBox_Byxpath);
		By passwordbox = By.xpath(EmailPageConstant.passwordbox_Byxpath);
		By signIn_textbutton = By.xpath(EmailPageConstant.signIn_textbutton_Byxpath);
		
		  
  
		public  void  email_inputBox_click() {


			WebElement ele = driver.findElement(inputBox);
			ele.sendKeys("test12@upgrade-challenge.com");
			test.log(LogStatus.PASS, "Email address Filled");
			
			

		}
		
		public  void  email_passwordbox() {


		WebElement password =  driver.findElement(passwordbox);
		password.sendKeys("Qwerty13");
		test.log(LogStatus.PASS, "Password Filled");
		

		}
		
		public  void click_signIn_textbutton() {


			WebElement signin_button = driver.findElement(signIn_textbutton);
			signin_button.click();

		}

}

package com.codingchallenge.PostPojo;

public class LoanApplication {
	
	
	

}

package com.upgrade.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.upgrade.constants.OfferPageConstant;

public class OfferPage {

	ExtentTest test;
	public WebDriver driver; 
	
      public OfferPage(WebDriver driver , ExtentTest test) {
			// TODO Auto-generated constructor stub
			this.driver = driver;
			this.test= test;
		}


	By laonAmount_Offered = By.xpath(OfferPageConstant.laonAmount_Offered_Byxpath);
	By MothlyAmount_Offered = By.xpath(OfferPageConstant.MothlyAmount_Offered_Byxpath);
	By MonthTerm_Offered = By.xpath(OfferPageConstant.MonthTerm_Offered_Byxpath);
	By InterestRate_Offered = By.xpath(OfferPageConstant.InterestRate_Offered_Byxpath);
	By aprEle_Offered = By.xpath(OfferPageConstant.aprEle_Offered_Byxpath);
	By menu_button = By.cssSelector(OfferPageConstant.menu_button_BycssSelector);
	By signOut_button = By.xpath(OfferPageConstant.signOut_button_Byxpath);



	public  WebElement offer_loanAmount_Offered() {

		test.log(LogStatus.INFO, "Captured  loanAmount_Offered");
		return driver.findElement(laonAmount_Offered);
		

	}

	public  WebElement offer_MothlyAmount_Offered() {

		test.log(LogStatus.INFO, "Captured  MothlyAmount_Offered");
		return driver.findElement(MothlyAmount_Offered);

	}

	public  WebElement offer_MonthTerm_Offered() {

		test.log(LogStatus.INFO, "Captured  MonthTerm_Offered");
		return driver.findElement(MonthTerm_Offered);

	}

	public  WebElement offer_InterestRate_Offeredd() {

		test.log(LogStatus.INFO, "Captured  InterestRate_Offeredd");
		return driver.findElement(InterestRate_Offered);

	}

	public  WebElement offer_aprEle_Offered() {

		test.log(LogStatus.INFO, "Captured  aprEle_Offered");
		return driver.findElement(aprEle_Offered);

	}
	
	
	public  WebElement offerPage_menu_button() {

		test.log(LogStatus.INFO, "Clicked on Menu buton");
		return driver.findElement(menu_button);

	}
	
	
	public  void offerPage_signOut_button() {

		test.log(LogStatus.INFO, "Signed_out");
		driver.findElement(signOut_button).click();
		test.log(LogStatus.INFO, "Signed_out");

	}
	
	

}

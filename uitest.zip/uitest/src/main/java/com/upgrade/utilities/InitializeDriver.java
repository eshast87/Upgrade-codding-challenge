package com.upgrade.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.apache.maven.surefire.shade.org.apache.maven.shared.utils.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;




public class InitializeDriver {



	public static WebDriver driver;
	public Properties prop;



	public WebDriver initializeDriver() throws IOException
	{

		prop= new Properties();
		FileInputStream fis=new FileInputStream(new File("").getAbsolutePath()+"/properties/data.properties"); prop.load(fis);
		String browserName=prop.getProperty("browser");
		System.out.println("The Selected Broweser is : "+browserName);


		if(browserName.equals("chrome"))

		{

			String Path = new File("").getAbsolutePath() + "/browserDriver/chromeDriver.exe";
			System.setProperty("webdriver.chrome.driver", Path);
			driver = new ChromeDriver();
			prop.load(fis);
			driver.get(prop.getProperty("url"));
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			return driver;



			/*
			 * String Path = new File("").getAbsolutePath() +
			 * "/browserDriver/chromeDriver.exe";
			 * System.setProperty("webdriver.chrome.driver", Path); driver = new
			 * ChromeDriver(); prop= new Properties(); FileInputStream fis = new
			 * FileInputStream(new
			 * File("").getAbsolutePath()+"/properties/data.properties"); prop.load(fis);
			 * driver.get(prop.getProperty("url")); driver.manage().window().maximize();
			 * driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS); return
			 * driver;
			 */

		}
		else if (browserName.equals("headless"))
		{
			WebDriver driver = new HtmlUnitDriver();
			prop.load(fis);
			driver.get(prop.getProperty("url"));
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			return driver;

		}
		else if (browserName.equals("IE"))
		{
			//		IE code
		}

		System.out.println("Please Set browser preference");
		return null;
	    }


	public String getScreenshot(String result) throws IOException
	   {
		File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File("C:\\UIUpgrade\\uitest\\Reports"+result+"screenshot.png"));
		String destination = "C:\\UIUpgrade\\uitest\\Reports"+result+"screenshot.png";
		return destination;
	   }

	public String takeScreenshot(WebDriver driver, String fileName) throws IOException {
		fileName = fileName + ".png";
		String directory = "C:\\UIUpgrade\\uitest\\Reports\\";
		File sourceFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(sourceFile, new File(directory + fileName));
		String destination = directory + fileName;
		return destination;
	  }


}



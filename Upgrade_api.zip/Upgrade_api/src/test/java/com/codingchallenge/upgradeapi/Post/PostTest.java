package com.codingchallenge.upgradeapi.Post;


import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import org.apache.logging.log4j.*;
import org.apache.logging.log4j.LogManager;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.codingchallenge.PostPojo.LoanApplication;
import com.codingchallenge.PostPojo.LoaninReviewPojo;
import com.codingchallenge.PostPojo.PostResponseParent;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


public class PostTest {

	Response response;
	PostResponseParent post_response;
	private static Logger log =LogManager.getLogger(PostTest.class.getName());




	@Test
	public void postRequest() {
		try {

			String username, password, postUri = "";

			Properties env_prop = new Properties(); 
			FileInputStream env_fis = new FileInputStream(new File("").getAbsolutePath()+"/properties/Environ.properties");
			env_prop.load(env_fis); postUri = env_prop.getProperty("POST_URI");

			Properties cred_prop = new Properties(); 
			FileInputStream cred_fis = new FileInputStream(new File("").getAbsolutePath()+"/properties/Creds.properties");
			cred_prop.load(cred_fis); 
			username = cred_prop.getProperty("USER");
			password = System.getProperty("password");
			log.info("The userName and Password are picked from the Credentail File with userName as : " + username + " Password:  " +password);


			HashMap<String, Object> hm = new HashMap<String, Object> ();
			hm.put("username", username); hm.put("password", password);

			RestAssured.baseURI = postUri;
			log.info(" Host information "+postUri);

			RequestSpecification httpRequest = RestAssured.given().log().uri();
			httpRequest.expect().defaultParser(Parser.JSON);

			httpRequest.header("Content-Type", "application/json").
			header("x-cf-source-id", "coding-challenge").
			header("x-cf-corr-id", "a754b154-dfbf-11e9-8a34-2a2ae2dbcce4");
			log.info(" Headers are added ");

			// Passing the Response body provided
			httpRequest.body(hm);
			log.info("The Post Json Body is "+hm);
			response = httpRequest.request(Method.POST, "/login");
			System.out.println("********The Response to the above Post is ************ "+" " + response.asString());
		}catch(Exception e) {
			System.out.println("Exception :: "+e.getMessage());
		}
		System.out.println("******** Challenge 2 : The StatusCode to the above Post is "+response.getStatusCode() +"  ************");
	}

	@Test 
	public void responseStatusCode_Validation() {

		log.info("Next Test is started to Validate the Status Code");
		int statusCode = response.getStatusCode();
		Assert.assertEquals(statusCode, 200);
		log.info("Response recieved is :"+response.asString());
		String content_type = response.getContentType();
		Assert.assertEquals(content_type, "application/json;charset=UTF-8");
		//log.trace(response);

	}


	@Test
	public void responseBody_Validation() {
		log.info("Challenge 2 has started to validate the value of Product Type is PERSONAL_LOAN");
		post_response = response.as(PostResponseParent.class);
		List<LoaninReviewPojo> res_productType = post_response.getLoansInReview();
		int length_ObjectIn_LoanReview = res_productType.size();
		System.out.println("The number of Ojects inside LoanReview Array is :" +length_ObjectIn_LoanReview);

		for (int i = 0 ; i<length_ObjectIn_LoanReview; i++) {

			String expected_productType_value = res_productType.get(i).getProductType();
			if (expected_productType_value.contentEquals("PERSONAL_LOAN")) {
				System.out.println("Then value of productType attribute is " + res_productType.get(i).getProductType());

			}
			else {
				System.out.println("The value of productType is not PERSONAL_LOAN");
			}
		}

		System.out.println("**************************Challenge 3************************************");
	}

	@Test
	public void wrongStatusCode() {
		HashMap<String, Object> hm2 = new HashMap<String, Object> ();
		hm2.put("username", "coding.challenge@upgrade.com");
		hm2.put("password","On$3XcgsW#");

		RestAssured.baseURI = "https://credapi.credify.tech/api/brportorch/v2/";
		RequestSpecification httpRequest = RestAssured.given();
		httpRequest.expect().defaultParser(Parser.JSON);
		httpRequest.header("Content-Type", "application/json").
		header("x-cf-source-id", "coding-challenge").
		header("x-cf-corr-id", "a754b154-dfbf-11e9-8a34-2a2ae2dbcce4");

		httpRequest.body(hm2).when();
		response = httpRequest.request(Method.POST, "/login");
		System.out.println("The response received from the above wrong_post body is "+response.asString());
		int wrong_statusCode = response.getStatusCode();
		Assert.assertEquals(wrong_statusCode, 401);
		System.out.println("The Status Code received from the above wrong_post body  "+wrong_statusCode);


	}

	@Test
	public void valueAssertioncheck() {

		PostResponseParent  response_login = response.as(PostResponseParent.class);
		String actual_firstName = response_login.getFirstName();
		Assert.assertEquals(actual_firstName, "Ian");
		int actual_userId = response_login.getUserId();
		Assert.assertEquals(actual_userId, 9114917);
		String actual_userUuid = response_login.getUserUuid();
		Assert.assertEquals(actual_userUuid, "34c16f53-38c4-461a-bd14-11fa748d2663");
		List<LoanApplication> actual_loanApplications = response_login.getLoanApplications();
		Boolean actual_loanApplication_empty= actual_loanApplications.isEmpty();
		Assert.assertTrue(actual_loanApplication_empty);
		List<LoaninReviewPojo> actual_loanInReview = response_login.getLoansInReview();
		int actual_id = actual_loanInReview.get(0).getId();
		Assert.assertEquals(actual_id, 9545966);
		String actual_uuid = actual_loanInReview.get(0).getUuid();
		Assert.assertEquals(actual_uuid,"230ea84a-7199-41c9-bf38-fff27e35970d");
		String actual_status = actual_loanInReview.get(0).getStatus();
		Assert.assertEquals(actual_status, "PENDING");
		String actual_productType = actual_loanInReview.get(0).getProductType();
		Assert.assertEquals(actual_productType, "PERSONAL_LOAN");
		String actual_sourceSystem = actual_loanInReview.get(0).getSourceSystem();
		Assert.assertEquals(actual_sourceSystem, "BORROWER_FUNNEL_V2");
		boolean actual_hasOpenBackendCounter = actual_loanInReview.get(0).getHasOpenBackendCounter();
		Assert.assertEquals(actual_hasOpenBackendCounter, false);
		String actual_purpose = actual_loanInReview.get(0).getPurpose();
		Assert.assertEquals(actual_purpose, "CREDIT_CARD");
		String actual_createDate = actual_loanInReview.get(0).getCreateDate();
		Assert.assertEquals(actual_createDate, "2019-08-21T18:18:59.959Z");
		String actual_postIssuanceStatus = actual_loanInReview.get(0).getPostIssuanceStatus();
		Assert.assertEquals(actual_postIssuanceStatus, null);

	}



}







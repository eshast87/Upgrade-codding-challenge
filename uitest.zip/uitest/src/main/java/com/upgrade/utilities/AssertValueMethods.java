package com.upgrade.utilities;

import org.openqa.selenium.WebDriver;

public class AssertValueMethods {
	
	WebDriver driver;
	
	public AssertValueMethods(WebDriver driver ) {
		this.driver = driver;
	}
	
	public void assertMethod(String expected, String actual) {
		if(expected == actual) {
			System.out.println("got it ");
		}else {
			System.out.println("not got it ");	}
		
		
	}
	

}

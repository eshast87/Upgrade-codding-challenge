package com.codingchallenge.utilities;

import java.util.HashMap;

public class Payloads {
	
	HashMap<String, Object> hm = new HashMap<String, Object> ();
	
	
	

}

package com.codingchallenge.PostPojo;

import java.util.List;

public class PostResponseParent {
	private String firstName;
	private int   userId;
	private String  userUuid;
	private List<LoanApplication> loanApplications;
	private List<LoaninReviewPojo> loansInReview;
	
	
public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserUuid() {
		return userUuid;
	}
	public void setUserUuid(String userUuid) {
		this.userUuid = userUuid;
	}
	public List<LoanApplication> getLoanApplications() {
		return loanApplications;
	}
	public void setLoanApplications(List<LoanApplication> loanApplications) {
		this.loanApplications = loanApplications;
	}
	public List<LoaninReviewPojo> getLoansInReview() {
		return loansInReview;
	}
	public void setLoansInReview(List<LoaninReviewPojo> loansInReview) {
		this.loansInReview = loansInReview;
	}



		}



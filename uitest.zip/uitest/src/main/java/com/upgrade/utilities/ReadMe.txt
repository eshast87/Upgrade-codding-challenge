1. -------------------Waits--------------------
I have used to waits for synchronisation  
1. Implicit wait : in IntializeDriver.java class
2. Explicit wait(WebDriver wait )  was used to click on the Menu page because of the Error I was getting : 

Error :org.openqa.selenium.NoSuchElementException: no such element: Unable to locate element: {"method":"xpath","selector":"//body/div[@id='root']/div[@class='layout__wrap']/main[@class='container-fluid layout__main layout-default']/div/div[@class='row row-lg']/div[@class='section col-xs-12 first-xs col-sm-8 col-sm-offset-2 col-md-8 col-md-offset-2']/div/div/div[@class='text--align-center']/div[@class='row row-lg center-xs']/div[@class='section--lg col-xs-6']/div[@class='row']/div[@class='text--align-left sc-gwVKww dDVIXz col-xs-12']/div[@class='sc-bsbRJL chqplK']/div[@class='sc-hXRMBi dslkRS']/div[@class='section--sm']/div[1] "}
  (Session info: chrome=76.0.3809.132)
  
  To solve this I used ExplicitWait.
  
  ------OOPS Concepst ----------------
  Inheritance : 
  Static : 
  POM : 
  Parameterization through TestNG 
  
  
  -------Jenkins
  Command to start on different port : java -jar jenkins.war -httpPort=9090
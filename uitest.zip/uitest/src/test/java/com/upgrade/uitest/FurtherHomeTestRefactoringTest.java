package com.upgrade.uitest;

import java.io.File;
import java.io.IOException;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.upgrade.pageObjects.EmailLoginPage;
import com.upgrade.pageObjects.LoginPage;
import com.upgrade.pageObjects.OfferPage;
import com.upgrade.pageObjects.RefactoredHomePage;
import com.upgrade.utilities.InitializeDriver;

public class FurtherHomeTestRefactoringTest extends InitializeDriver {

	ExtentReports extent;


	String nextUrlToNavigate = "https://www.credify.tech/portal/login";
	ExtentReports report;
	ExtentTest test;


	@BeforeTest
	public void beforeSuite() throws IOException {
		
		report = new ExtentReports(new File("").getAbsolutePath()+"/Reports/Report_test.html");
		test = report.startTest("test");
		driver = initializeDriver();
		test.log(LogStatus.INFO, "Browser launched successfully ");
		test.log(LogStatus.INFO, "Browser maxmimized ");
		test.assignAuthor("Esha Singh");
		test.assignCategory("Challenge for Upgrade UI Automation Completed");

	}

	@Test
	private void UpgardeFormPage() throws InterruptedException, IOException {
		LoginPage lp = new LoginPage(driver,test);
		RefactoredHomePage hm = new RefactoredHomePage(driver,test);
		hm.fill_in_loanAmmount();
		hm.fill_in_purpose();
		hm.click_checkyourRate();
		lp.fill_firstName();
		lp.fill_lastName();
		lp.fill_browserStreet();
		Thread.sleep(2000);
		lp.fill_borrowerCity();
		lp.fill_borrowerState();
		lp.fill_borrowerZipCode();
		lp.fill_borrowerDateOfBirth();
		lp.fill_borrowerIncome();
		lp.fill_borrowerAdditionalIncome();
		lp.fill_username();
		lp.fill_password();
		Thread.sleep(2000);
		lp.fill_check_boxterms().click();;
		lp.fill_check_ratebutton().click();
		Thread.sleep(2000);
		OfferPage op = new OfferPage(driver,test);
		String Expected_offer_loanAmt_Offered = op.offer_loanAmount_Offered().getText();
		System.out.println(Expected_offer_loanAmt_Offered);
		String Expected_offer_MothlyAmount_Offered= op.offer_MothlyAmount_Offered().getText();
		System.out.println(Expected_offer_MothlyAmount_Offered);
		String Expected_offer_MonthTerm_Offered = op.offer_MonthTerm_Offered().getText();
		System.out.println(Expected_offer_MonthTerm_Offered);
		String Expected_offer_InterestRate_Offeredd = op.offer_InterestRate_Offeredd().getText();
		System.out.println(Expected_offer_InterestRate_Offeredd);
		String Expected_offer_aprEle_Offered  = op.offer_aprEle_Offered().getText();
		System.out.println(Expected_offer_aprEle_Offered);
		Thread.sleep(1000);
		op.offerPage_menu_button().click();
		Thread.sleep(1000);
		op.offerPage_signOut_button();
		Thread.sleep(1000);
		driver.navigate().to(nextUrlToNavigate);
		EmailLoginPage ep = new EmailLoginPage(driver,test);
		ep.email_inputBox_click();
		ep.email_passwordbox();
		ep.click_signIn_textbutton();
		String Actual_offer_loanAmt_Offered = op.offer_loanAmount_Offered().getText();
		System.out.println(Actual_offer_loanAmt_Offered);
		String Actual_offer_MothlyAmount_Offered= op.offer_MothlyAmount_Offered().getText();
		System.out.println(Actual_offer_MothlyAmount_Offered);
		String Actual_offer_MonthTerm_Offered = op.offer_MonthTerm_Offered().getText();
		System.out.println(Actual_offer_MonthTerm_Offered);
		String Actual_offer_InterestRate_Offeredd = op.offer_InterestRate_Offeredd().getText();
		System.out.println(Actual_offer_InterestRate_Offeredd);
		String Actual_offer_aprEle_Offered  = op.offer_aprEle_Offered().getText();
		System.out.println(Actual_offer_aprEle_Offered);

		Assert.assertEquals(Expected_offer_loanAmt_Offered, Actual_offer_loanAmt_Offered);
		Assert.assertEquals(Expected_offer_MonthTerm_Offered, Actual_offer_MonthTerm_Offered);
		Assert.assertEquals(Expected_offer_MothlyAmount_Offered, Actual_offer_MothlyAmount_Offered);
		Assert.assertEquals(Expected_offer_InterestRate_Offeredd, Actual_offer_InterestRate_Offeredd);
		Assert.assertEquals(Expected_offer_aprEle_Offered, Actual_offer_aprEle_Offered);


	}



	@AfterMethod
	public void tearDown(ITestResult testResult) throws IOException {
		if (testResult.getStatus() == ITestResult.SUCCESS) {
			String path = takeScreenshot(driver, testResult.getName());
			String imagePath = test.addScreenCapture(path);
			test.log(LogStatus.PASS, "Upgarde is successfully Automated", imagePath);
		}

		driver.quit();
		report.endTest(test);
		report.flush();
	}






}

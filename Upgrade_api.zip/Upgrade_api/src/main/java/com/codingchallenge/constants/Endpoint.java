package com.codingchallenge.constants;

public class Endpoint {
	public static final String STATES_READ_GET = "/states";
	

}

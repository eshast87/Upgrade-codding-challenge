package com.codingchalllenge.upgradeapi.Get_upgrade;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.codingchallenge.GetPojo.getStatesParent;
import com.codingchallenge.GetPojo.state;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class GetUpgradeTest {

@Test
public void Serialisation() {
	
	
	

	
	 try {
		 RestAssured.baseURI = "https://credapi.credify.tech/api/loanapp/v1/";
		 RequestSpecification httpRequest = RestAssured.given();
		 httpRequest.expect().defaultParser(Parser.JSON);
		 // when ur reposnse contentType is not application/jason
		 //httpRequest.expect().defaultParser(Parser.JSON);
		 Response response = httpRequest.request(Method.GET, "/states");
	int Code =  response.getStatusCode();
	System.out.println(Code);
		 // Use the POJO class
		 getStatesParent  response_State = response.as(getStatesParent.class);
		
	String Labelr=response_State.getStates().get(1).getLabel();
		System.out.println(Labelr);
		
		List<state> res_states = response_State.getStates();
	int Size_statesList = res_states.size();
	System.out.println("The no of States returned are : " + Size_statesList);
	int count = 0;
	 for(int i= 0 ; i<=Size_statesList ; i++) {
		 String req_state =res_states.get(i).getLabel();
		 int min_loanAmount = res_states.get(i).getMinLoanAmount();
		int age = res_states.get(i).getMinAge();
		 if(age==18){
			 count++;
			 System.out.println("The only state which has minAge 18 is " +req_state );

	if (count==1) {
			
		System.out.println("There is only one state "+req_state);}
	else {System.out.println("There are more than one state which has minAge more than 19");}
	
		}
		 
		 if (min_loanAmount ==3005) {
			 System.out.println("The only State " +req_state+"which has minimum Loan amount of is "+min_loanAmount);
		 }
		
	 }
	 
	 
	 System.out.println("I am here " );
	 
	 String[] Expected_states ={
		     "Alabam","Alaska","Arizona","Arkansa", "California","Connecticut","Delaware", "District of Columbia",
			 "Florida","Georgia", "Hawaii","Idaho","Illinois", "Indiana","Kansas","Kentucky","Louisiana", "Maine","Maryland","Massachusetts","Michigan","Minnesota","Mississippi","Missouri","Montana","Nebraska",
		 "Nevada","New Hampshire","New Jersey", "New Mexico","New York","North Carolina","North Dakota","Ohio","Oklahoma", "Oregon","Pennsylvania","Rhode Island","South Carolina","South Dakota",
		 "Tennessee", "Texas", "Utah","Vermont","Virginia","Washington", "Wyoming"};
	
	 ArrayList<String> a = new ArrayList<String>();
	 
	 
	 for (int i = 0;i<=Size_statesList;i++) {
		 String l_response = res_states.get(i).getLabel();
	 a.add(l_response);
	 }
	 
	List<String> Expected_states_response = Arrays.asList(Expected_states);
	
	Assert.assertTrue(a.equals(Expected_states_response));
	 
	 
	 
	 }
	 catch(Exception e) {
    e.getStackTrace();



}}}
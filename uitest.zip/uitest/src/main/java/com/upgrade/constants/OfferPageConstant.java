package com.upgrade.constants;


public class OfferPageConstant {
	
	public static final	String xp = "//body/div[@id='root']/div[@class='layout__wrap']/main[@class='container-fluid layout__main layout-default']/div/div[@class='row row-lg']/div[@class='section col-xs-12 first-xs col-sm-8 col-sm-offset-2 col-md-8 col-md-offset-2']/div/div/div[@class='text--align-center']/div[@class='row row-lg center-xs']/div[@class='section--lg col-xs-6']/div[@class='row']/div[@class='text--align-left sc-gwVKww dDVIXz col-xs-12']/div[@class='sc-bsbRJL chqplK']/div[@class='sc-hXRMBi fuKCMP']/div[@class='section--sm']/div[1]";
	public static final	String css = "div.layout__wrap main.container-fluid.layout__main.layout-default:nth-child(4) div.row.row-lg div.section.col-xs-12.first-xs.col-sm-8.col-sm-offset-2.col-md-8.col-md-offset-2 div.text--align-center div.row.row-lg.center-xs div.section--lg.col-xs-6 div.row div.text--align-left.sc-gwVKww.dDVIXz.col-xs-12 div.sc-bsbRJL.chqplK div.sc-hXRMBi.fuKCMP div.section--sm:nth-child(1) > div.section--xs:nth-child(1)";
	

	public static final String laonAmount_Offered_Byxpath = "//span[@class='sc-chPdSV VlhWk']";
	public static final String MothlyAmount_Offered_Byxpath = "//span[contains(text(),'$67.74')]";
	public static final String MonthTerm_Offered_Byxpath = xp;
	public static final String InterestRate_Offered_Byxpath = "//div[@class='sc-bsbRJL chqplK']//div[2]";
	public static final String aprEle_Offered_Byxpath = "//div[@class='sc-hZSUBg dMzhYO']//div[1]";
	public static final String menu_button_BycssSelector = ".header-nav .header-nav__toggle:nth-child(2)";
	public static final String signOut_button_Byxpath = "//a[contains(text(),'Sign Out')]";

}

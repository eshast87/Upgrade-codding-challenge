package com.codingchallenge.GetPojo;

import java.util.List;

public class getStatesParent {
	
	private List<state> states;

	public List<state> getStates() {
		return states;
	}

	public void setStates(List<state> states) {
		this.states = states;
	}
	
	


}
	



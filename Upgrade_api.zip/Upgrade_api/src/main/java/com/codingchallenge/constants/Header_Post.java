package com.codingchallenge.constants;

public class Header_Post {
	public static final String Content_Type = "";
	public static final String CONSUMER_SECRET = "";
	public static final String ACCESS_TOKEN = "";
	public static final String ACCESS_SECRET = "";
}

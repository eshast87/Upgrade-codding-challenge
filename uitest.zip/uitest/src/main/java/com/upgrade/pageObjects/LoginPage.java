package com.upgrade.pageObjects;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.upgrade.constants.LoginPageConstant;

public class LoginPage {

	ExtentTest test;
	public WebDriver driver; 
	
      public LoginPage(WebDriver driver , ExtentTest test) {
			// TODO Auto-generated constructor stub
			this.driver = driver;
			this.test= test;
		}

	By firstName = By.name(LoginPageConstant.firstName_Byname);
	By lastName = By.name(LoginPageConstant.lastName_Byname);
	By browserStreet = By.className(LoginPageConstant.browserStreet_ByclassName);
	By borrowerCity = By.name(LoginPageConstant.borrowerCity_Byname);
	By borrowerState = By.name(LoginPageConstant.borrowerState_Byname);
	By borrowerZipCode = By.name(LoginPageConstant.borrowerZipCode_Byname);
	By borrowerDateOfBirth = By.name(LoginPageConstant.borrowerDateOfBirth_Byname);
	By borrowerIncome = By.name(LoginPageConstant.borrowerIncome_Byname);
	By borrowerAdditionalIncome = By.name(LoginPageConstant.borrowerAdditionalIncome_Byname);
	By username = By.name(LoginPageConstant.username_Byname);
	By password = By.name(LoginPageConstant.password_Byname);
	By check_boxterms = By.xpath(LoginPageConstant.check_boxterms_Byxpath);
	By check_ratebutton = By.xpath(LoginPageConstant.check_ratebutton_Byxpath);
	


	public void fill_firstName() {


		WebElement fill_firstName = driver.findElement(firstName);
		
		fill_firstName.sendKeys("test21");
		test.log(LogStatus.INFO, " firstname Filled ");
	}

	  public void fill_lastName() {


		WebElement fill_lastName = driver.findElement(lastName);
		fill_lastName.sendKeys("pass21");
		test.log(LogStatus.INFO, " lastname Filled ");

	}
	  

	public  void fill_browserStreet() {
		 WebElement fill_browserStreet =driver.findElement(By.name("borrowerStreet"));
		 fill_browserStreet.sendKeys("120 Broadway");
		 test.log(LogStatus.INFO, " Street name  Filled ");
	}
	
	public  void fill_borrowerCity() {


		WebElement fill_borrowerCity =  driver.findElement(borrowerCity);
		fill_borrowerCity.sendKeys("New York");
		test.log(LogStatus.INFO, " City Filled ");
		
	}
	
	
	public  void fill_borrowerState() {


		WebElement fill_borrowerState =  driver.findElement(borrowerState);
		fill_borrowerState.sendKeys("NY");
		test.log(LogStatus.INFO, " State  Filled ");
		
	}
	


	public  void fill_borrowerZipCode() {


		WebElement fill_borrowerZipCode =  driver.findElement(borrowerZipCode);
		fill_borrowerZipCode.sendKeys("282323");
		test.log(LogStatus.INFO, " ZipCode Filled ");

	}

	public  void fill_borrowerDateOfBirth() {


		WebElement fill_borrowerDateOfBirth =  driver.findElement(borrowerDateOfBirth);
		fill_borrowerDateOfBirth.sendKeys("03/05/1987");
		test.log(LogStatus.INFO, " Date of Birth  Filled ");

	}

	public  void fill_borrowerIncome() {


		WebElement fill_borrowerIncome =  driver.findElement(borrowerIncome);
		fill_borrowerIncome.sendKeys("140,000");
		test.log(LogStatus.INFO, " Bowrrower Income Filled ");

	}

	public  void fill_borrowerAdditionalIncome() {


		WebElement fill_borrowerAdditionalIncome =  driver.findElement(borrowerAdditionalIncome);
		fill_borrowerAdditionalIncome.sendKeys("6000");
		test.log(LogStatus.INFO, " Additional Income  Filled ");
		
	}

	public  void fill_username() {


		WebElement fill_username =  driver.findElement(username);
		fill_username.sendKeys("test12@upgrade-challenge.com");
		test.log(LogStatus.INFO, " UserName Filled ");
	}

	public  void fill_password() {


		WebElement fill_password =  driver.findElement(password);
		fill_password.sendKeys("Qwerty13");
		test.log(LogStatus.INFO, " Password Filled ");
	

	}
	

	public WebElement fill_check_boxterms() {
		test.log(LogStatus.INFO, " Check box clicked ");


		return driver.findElement(check_boxterms);
		
		
	}

	public  WebElement fill_check_ratebutton() {

		test.log(LogStatus.INFO, " Check rate clicked ");
	 return driver.findElement(check_ratebutton);
	
		

	}









}

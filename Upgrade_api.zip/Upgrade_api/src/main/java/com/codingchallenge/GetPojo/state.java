package com.codingchallenge.GetPojo;

public class state {
	private String label;
	private String abbreviation;
	private int minLoanAmount;
	private int  minAge;
	
	
	// POJO For Serialization and Deserialization 
	// supporting liubraries are JackSon, JackSOn2 , Gson.
	
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getAbbreviation() {
		return abbreviation;
	}
	public void setAbbreviation(String abbreviation) {
		this.abbreviation = abbreviation;
	}
	public int getMinLoanAmount() {
		return minLoanAmount;
	}
	public void setMinLoanAmount(int minLoanAmount) {
		this.minLoanAmount = minLoanAmount;
	}
	public int getMinAge() {
		return minAge;
	}
	public void setMinAge(int minAge) {
		this.minAge = minAge;
	}
	

}

package com.upgrade.constants;


public class HomePageConstant {
	
	public static final String laonAmount_byName = "desiredAmount";
	public static final String purpose_Byxpath = "//select[@class='sc-dVhcbM iHtznt']";
	public static final String checkyourRate_Byxpath = "//button[@class='sc-jhAzac FTzFC sc-brqgnP elTcgq']";

}

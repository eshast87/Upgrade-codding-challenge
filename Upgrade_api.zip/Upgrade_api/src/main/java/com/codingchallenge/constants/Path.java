package com.codingchallenge.constants;

public class Path {

		public static final String BASE_URI = "https://credapi.credify.tech";
		public static final String VERSION = "/api/loanapp/v1";
		

}
